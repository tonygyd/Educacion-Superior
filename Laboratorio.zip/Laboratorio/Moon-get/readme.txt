"MOON GET!" is a typeface base on the "YOU GOT A MOON!" text and other various HUD elements of the Nintendo Switch game "Super Mario Odyssey".

Super Mario Odyssey is a trademark of Nintendo Co., Ltd.

2018 - MaxiGamer